enemies = ['elephant', 'robot', 'snake', 'vampire', 'wicked fairie', 'troll']

weapons = ['shiny sword', 'wooden stick', 'huge rock', 'grumpy kittens']
